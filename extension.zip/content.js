// YouTube SEO AGI Tool - Content Script
// Injects SEO data and optimization suggestions into YouTube pages
// Also provides auto-fill functionality for YouTube Studio

(function() {
  'use strict';
  
  // Configuration
  const CONFIG = {
    apiBaseUrl: 'https://your-app-url.streamlit.app/api', // TODO: Update with actual URL
    showSEOOverlay: true,
    showKeywordSuggestions: true,
    autoFillEnabled: true, // Enable auto-fill feature
    autoFillDelay: 500 // Delay before auto-filling (ms)
  };
  
  // Extract video ID from URL
  function getVideoId() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('v');
  }
  
  // Extract channel handle from page
  function getChannelHandle() {
    // Try multiple selectors for channel handle
    const channelLink = document.querySelector('ytd-channel-name a, ytd-video-owner-renderer a');
    if (channelLink) {
      const href = channelLink.getAttribute('href');
      if (href) {
        const match = href.match(/\/(?:c|channel|user|@)([^\/]+)/);
        if (match) {
          return match[1].replace('@', '');
        }
      }
    }
    return null;
  }
  
  // Check if we're on YouTube Studio
  function isYouTubeStudio() {
    return window.location.hostname.includes('studio.youtube.com') || 
           window.location.pathname.includes('/studio');
  }
  
  // Check if we're on YouTube video watch page
  function isVideoWatchPage() {
    return window.location.pathname === '/watch' && getVideoId();
  }
  
  // Auto-fill YouTube Studio form fields
  function autoFillYouTubeStudio(data) {
    if (!CONFIG.autoFillEnabled) return;
    
    // Wait for form to load
    setTimeout(() => {
      // Title field
      const titleField = document.querySelector('input[aria-label*="Title"], input[name*="title"], #textbox[aria-label*="Title"]');
      if (titleField && data.title_suggestions && data.title_suggestions.length > 0) {
        if (!titleField.value) {
          titleField.value = data.title_suggestions[0];
          titleField.dispatchEvent(new Event('input', { bubbles: true }));
          titleField.dispatchEvent(new Event('change', { bubbles: true }));
          console.log('✅ Auto-filled title');
        }
      }
      
      // Description field
      const descriptionField = document.querySelector('textarea[aria-label*="Description"], textarea[name*="description"], #textbox[aria-label*="Description"]');
      if (descriptionField && data.description) {
        if (!descriptionField.value || descriptionField.value.length < 100) {
          descriptionField.value = data.description;
          descriptionField.dispatchEvent(new Event('input', { bubbles: true }));
          descriptionField.dispatchEvent(new Event('change', { bubbles: true }));
          console.log('✅ Auto-filled description');
        }
      }
      
      // Tags field
      const tagsField = document.querySelector('input[aria-label*="Tags"], input[name*="tags"], #chips-input input');
      if (tagsField && data.tags && data.tags.length > 0) {
        // YouTube tags are usually chip-based, try to add them
        const tagsToAdd = data.tags.slice(0, 15).join(', ');
        if (tagsField.value !== tagsToAdd) {
          tagsField.value = tagsToAdd;
          tagsField.dispatchEvent(new Event('input', { bubbles: true }));
          // Try to trigger chip creation (press Enter)
          tagsField.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
          console.log('✅ Auto-filled tags');
        }
      }
      
      // Show notification
      showAutoFillNotification('Auto-filled form fields from SEO analysis');
    }, CONFIG.autoFillDelay);
  }
  
  // Show auto-fill notification
  function showAutoFillNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'youtube-seo-autofill-notification';
    notification.innerHTML = `
      <div class="youtube-seo-notification-content">
        <span class="youtube-seo-notification-icon">✅</span>
        <span class="youtube-seo-notification-text">${message}</span>
        <button class="youtube-seo-notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
      </div>
    `;
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 5000);
  }
  
  // Create SEO overlay
  function createSEOOverlay(seoData) {
    const overlay = document.createElement('div');
    overlay.id = 'youtube-seo-overlay';
    overlay.className = 'youtube-seo-overlay';
    
    const score = seoData.seo_score || 0;
    const scoreColor = score >= 80 ? '#4caf50' : score >= 60 ? '#ffc107' : '#f44336';
    
    overlay.innerHTML = `
      <div class="youtube-seo-header">
        <span class="youtube-seo-title">🎸 SEO Score</span>
        <button class="youtube-seo-close" onclick="this.parentElement.parentElement.remove()">×</button>
      </div>
      <div class="youtube-seo-content">
        <div class="youtube-seo-score" style="color: ${scoreColor}">
          ${score}/100
        </div>
        <div class="youtube-seo-breakdown">
          <div class="youtube-seo-item">
            <span>Title:</span>
            <span class="youtube-seo-value ${seoData.title_score >= 80 ? 'good' : seoData.title_score >= 60 ? 'medium' : 'poor'}">
              ${seoData.title_score || 0}/100
            </span>
          </div>
          <div class="youtube-seo-item">
            <span>Description:</span>
            <span class="youtube-seo-value ${seoData.description_score >= 80 ? 'good' : seoData.description_score >= 60 ? 'medium' : 'poor'}">
              ${seoData.description_score || 0}/100
            </span>
          </div>
          <div class="youtube-seo-item">
            <span>Tags:</span>
            <span class="youtube-seo-value ${seoData.tags_score >= 80 ? 'good' : seoData.tags_score >= 60 ? 'medium' : 'poor'}">
              ${seoData.tags_score || 0}/100
            </span>
          </div>
        </div>
        ${seoData.recommendations && seoData.recommendations.length > 0 ? `
          <div class="youtube-seo-recommendations">
            <strong>💡 Quick Tips:</strong>
            <ul>
              ${seoData.recommendations.slice(0, 3).map(rec => `<li>${rec}</li>`).join('')}
            </ul>
          </div>
        ` : ''}
        <div class="youtube-seo-actions">
          <button class="youtube-seo-btn youtube-seo-btn-primary" id="autofill-btn">
            ✨ Auto-Fill Form
          </button>
          <a href="${CONFIG.apiBaseUrl.replace('/api', '')}" target="_blank" class="youtube-seo-link">
            View Full Analysis →
          </a>
        </div>
      </div>
    `;
    
    // Add auto-fill button handler
    overlay.querySelector('#autofill-btn').addEventListener('click', () => {
      if (isYouTubeStudio()) {
        autoFillYouTubeStudio(seoData);
      } else {
        // If on watch page, redirect to studio
        const videoId = getVideoId();
        if (videoId) {
          window.open(`https://studio.youtube.com/video/${videoId}/edit`, '_blank');
        }
      }
    });
    
    return overlay;
  }
  
  // Inject SEO overlay into page
  function injectSEOOverlay(seoData) {
    // Remove existing overlay
    const existing = document.getElementById('youtube-seo-overlay');
    if (existing) {
      existing.remove();
    }
    
    // Create and inject new overlay
    const overlay = createSEOOverlay(seoData);
    
    // Find insertion point
    if (isYouTubeStudio()) {
      // Insert near form fields
      const formContainer = document.querySelector('ytd-upload-dialog, ytd-metadata-editor, form');
      if (formContainer) {
        formContainer.insertBefore(overlay, formContainer.firstChild);
      } else {
        document.body.appendChild(overlay);
      }
    } else {
      // For watch pages, insert near video info
      const target = document.querySelector('#above-the-fold, #primary, ytd-watch-metadata');
      if (target) {
        target.insertBefore(overlay, target.firstChild);
      } else {
        document.body.appendChild(overlay);
      }
    }
  }
  
  // Show keyword suggestions
  function showKeywordSuggestions(keywords) {
    // Find description area
    const description = document.querySelector('#description, ytd-expander #content');
    if (description && keywords && keywords.length > 0) {
      const keywordBox = document.createElement('div');
      keywordBox.className = 'youtube-seo-keywords';
      keywordBox.innerHTML = `
        <div class="youtube-seo-keywords-header">
          <strong>🔑 Suggested Keywords:</strong>
        </div>
        <div class="youtube-seo-keywords-list">
          ${keywords.slice(0, 10).map(kw => `<span class="youtube-seo-keyword-tag">${kw}</span>`).join('')}
        </div>
      `;
      
      // Insert after description
      description.parentNode.insertBefore(keywordBox, description.nextSibling);
    }
  }
  
  // Main function to analyze current video
  async function analyzeCurrentVideo() {
    const videoId = getVideoId();
    if (!videoId && !isYouTubeStudio()) {
      return; // Not on a video page or studio
    }
    
    const channelHandle = getChannelHandle();
    
    try {
      // Request SEO analysis from background script
      chrome.runtime.sendMessage({
        action: 'getSEOAnalysis',
        videoId: videoId,
        channelHandle: channelHandle,
        isStudio: isYouTubeStudio()
      }, (response) => {
        if (response && response.success && response.data) {
          if (CONFIG.showSEOOverlay) {
            injectSEOOverlay(response.data);
          }
          
          // Auto-fill if on YouTube Studio
          if (isYouTubeStudio() && CONFIG.autoFillEnabled) {
            autoFillYouTubeStudio(response.data);
          }
          
          if (CONFIG.showKeywordSuggestions && response.data.keywords) {
            showKeywordSuggestions(response.data.keywords);
          }
        }
      });
    } catch (error) {
      console.error('Error analyzing video:', error);
    }
  }
  
  // Run analysis when page loads
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(analyzeCurrentVideo, 2000); // Wait for YouTube to load
    });
  } else {
    setTimeout(analyzeCurrentVideo, 2000);
  }
  
  // Re-analyze when navigating to new video (YouTube SPA)
  let lastVideoId = getVideoId();
  let lastUrl = window.location.href;
  const observer = new MutationObserver(() => {
    const currentVideoId = getVideoId();
    const currentUrl = window.location.href;
    
    // Check if URL changed (new video or navigation)
    if (currentUrl !== lastUrl || (currentVideoId && currentVideoId !== lastVideoId)) {
      lastVideoId = currentVideoId;
      lastUrl = currentUrl;
      setTimeout(analyzeCurrentVideo, 2000);
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Listen for messages from popup or background
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'analyzeVideo') {
      analyzeCurrentVideo();
      sendResponse({ success: true });
    } else if (request.action === 'autoFill') {
      if (request.data) {
        autoFillYouTubeStudio(request.data);
        sendResponse({ success: true });
      }
    }
    return true; // Keep channel open for async response
  });
  
})();
