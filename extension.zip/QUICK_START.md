# 🚀 Hızlı Başlangıç - Browser Extension

5 dakikada extension'ı aktif edin ve kullanmaya başlayın!

## ⚡ Hızlı Kurulum (Chrome)

### 1. Developer Mode'u Aç
```
Chrome → chrome://extensions/ → Developer mode ON
```

### 2. Extension'ı Yükle
```
"Load unpacked" → extension klasörünü seç
```

### 3. API URL'ini Güncelle
`extension/background.js` ve `extension/content.js` dosyalarında:
```javascript
// Değiştir:
const API_BASE_URL = 'https://your-app-url.streamlit.app/api';

// Kendi URL'inizle:
const API_BASE_URL = 'https://your-app-name.streamlit.app/api';
```

### 4. Test Et
1. YouTube'da bir video açın
2. SEO skoru görünmeli
3. "✨ Auto-Fill Form" butonuna tıklayın

## 🎯 YouTube Studio'da Otomatik Doldurma

### Nasıl Çalışır?

1. **YouTube Studio'ya gidin:**
   ```
   https://studio.youtube.com/video/VIDEO_ID/edit
   ```

2. **Extension otomatik analiz yapar:**
   - Video ID'yi algılar
   - SEO analizi yapar
   - Önerileri hazırlar

3. **"✨ Auto-Fill Form" butonuna tıklayın:**
   - Title otomatik doldurulur
   - Description otomatik doldurulur
   - Tags otomatik eklenir

### Manuel Kullanım

Eğer otomatik doldurma çalışmazsa:

1. Extension popup'ını açın (toolbar icon)
2. "🔍 Analyze Current Video" tıklayın
3. Sonuçları görüntüleyin
4. "✨ Auto-Fill Form" butonunu kullanın

## 🔑 API Key Yapılandırması

Extension, dashboard'daki API key'i kullanır:

1. Dashboard'a giriş yapın
2. Sidebar'dan YouTube API key'inizi girin
3. Extension otomatik olarak bu key'i kullanır

## ✅ Kontrol Listesi

- [ ] Extension yüklendi
- [ ] API URL'leri güncellendi
- [ ] Dashboard'da API key yapılandırıldı
- [ ] YouTube'da SEO skoru görünüyor
- [ ] Auto-fill butonu çalışıyor

## 🐛 Hızlı Sorun Giderme

**Extension görünmüyor?**
- `chrome://extensions/` → Extension'ın aktif olduğundan emin olun

**SEO skoru görünmüyor?**
- Console'u açın (F12) → Hata var mı kontrol edin
- API URL'lerinin doğru olduğundan emin olun

**Auto-fill çalışmıyor?**
- YouTube Studio'da olduğunuzdan emin olun
- Sayfanın tamamen yüklendiğinden emin olun
- Form alanlarının boş olduğundan emin olun

## 📞 Yardım

Detaylı bilgi için: `extension/INSTALLATION.md`

