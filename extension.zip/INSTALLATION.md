# Browser Extension Kurulum Kılavuzu

YouTube SEO AGI Tool browser extension'ını Chrome veya Firefox'a nasıl yükleyeceğinizi öğrenin.

## 📋 Gereksinimler

- Chrome 88+ veya Firefox 109+
- YouTube SEO AGI Tool hesabı (dashboard'da API key yapılandırılmış olmalı)

## 🚀 Chrome'a Yükleme

### Adım 1: Extension Dosyalarını Hazırlayın

1. `extension` klasörünün tam yolunu not edin:
   ```
   C:\Users\morig\Desktop\YouTube-SEO-AGI-Tool\extension
   ```

### Adım 2: Chrome Developer Mode'u Aktifleştirin

1. Chrome'u açın
2. Adres çubuğuna şunu yazın: `chrome://extensions/`
3. Sağ üst köşede **"Developer mode"** (Geliştirici modu) toggle'ını **AÇIK** yapın

### Adım 3: Extension'ı Yükleyin

1. **"Load unpacked"** (Paketlenmemiş yükle) butonuna tıklayın
2. `extension` klasörünü seçin
3. Extension yüklenecek ve listede görünecek

### Adım 4: Extension'ı Yapılandırın

1. Extension'ın yanındaki **"Details"** (Detaylar) butonuna tıklayın
2. **"Allow access to file URLs"** seçeneğini açın (gerekirse)
3. Extension'ın izinlerini kontrol edin

## 🦊 Firefox'a Yükleme

### Adım 1: Geçici Eklenti Olarak Yükleme (Geliştirme)

1. Firefox'u açın
2. Adres çubuğuna şunu yazın: `about:debugging`
3. Sol menüden **"This Firefox"** seçin
4. **"Load Temporary Add-on"** butonuna tıklayın
5. `extension/manifest.json` dosyasını seçin

**Not:** Firefox'ta geçici eklentiler tarayıcı yeniden başlatıldığında kaldırılır.

### Adım 2: Kalıcı Yükleme (Önerilen)

Firefox için kalıcı yükleme için extension'ı paketlemeniz gerekir:

1. `manifest.json` dosyasını Firefox formatına uygun hale getirin
2. Extension'ı ZIP olarak paketleyin
3. Firefox Add-ons Developer Hub'dan yükleyin

## ⚙️ Yapılandırma

### API URL'ini Güncelleme

1. `extension/background.js` dosyasını açın
2. `API_BASE_URL` değişkenini bulun:
   ```javascript
   const API_BASE_URL = 'https://your-app-url.streamlit.app/api';
   ```
3. Kendi Streamlit Cloud URL'inizle değiştirin:
   ```javascript
   const API_BASE_URL = 'https://your-app-name.streamlit.app/api';
   ```

4. `extension/content.js` dosyasında da aynı değişikliği yapın:
   ```javascript
   apiBaseUrl: 'https://your-app-name.streamlit.app/api',
   ```

5. `extension/popup.js` dosyasında dashboard URL'ini güncelleyin:
   ```javascript
   chrome.tabs.create({ url: 'https://your-app-name.streamlit.app' });
   ```

### API Key Yapılandırması

Extension, dashboard'daki API key'i kullanır. Extension'ı kullanmadan önce:

1. Dashboard'a giriş yapın
2. Sidebar'dan API key'inizi girin
3. Extension otomatik olarak bu key'i kullanacaktır

## 🎯 Kullanım

### YouTube Watch Sayfasında

1. Herhangi bir YouTube videosunu açın
2. Extension otomatik olarak SEO analizi yapar
3. Video bilgilerinin yanında SEO skoru görünür
4. **"✨ Auto-Fill Form"** butonuna tıklayarak YouTube Studio'ya yönlendirilirsiniz

### YouTube Studio'da

1. YouTube Studio'ya gidin: https://studio.youtube.com
2. Yeni video yüklerken veya düzenlerken:
   - Extension otomatik olarak SEO analizi yapar
   - **"✨ Auto-Fill Form"** butonuna tıklayın
   - Title, Description ve Tags alanları otomatik doldurulur

### Manuel Auto-Fill

1. Extension popup'ını açın (toolbar'daki icon)
2. **"🔍 Analyze Current Video"** butonuna tıklayın
3. Analiz tamamlandıktan sonra **"✨ Auto-Fill Form"** butonunu kullanın

## 🔧 Sorun Giderme

### Extension Çalışmıyor

1. **Console'u kontrol edin:**
   - Chrome: F12 > Console
   - Hata mesajlarını kontrol edin

2. **API URL'ini kontrol edin:**
   - `background.js` ve `content.js` dosyalarındaki URL'lerin doğru olduğundan emin olun

3. **İzinleri kontrol edin:**
   - Extension'ın YouTube ve Studio sayfalarına erişim izni olduğundan emin olun

### Auto-Fill Çalışmıyor

1. **YouTube Studio'da olduğunuzdan emin olun:**
   - URL: `https://studio.youtube.com/video/VIDEO_ID/edit`

2. **Form alanlarının yüklendiğinden emin olun:**
   - Sayfanın tamamen yüklenmesini bekleyin
   - Extension otomatik olarak 2 saniye bekler

3. **Manuel doldurmayı deneyin:**
   - Extension popup'ından analiz sonuçlarını görüntüleyin
   - Sonuçları manuel olarak kopyalayıp yapıştırın

### API Bağlantı Hatası

1. **API key'inizi kontrol edin:**
   - Dashboard'da API key'in doğru yapılandırıldığından emin olun

2. **CORS ayarlarını kontrol edin:**
   - Backend API'nin CORS ayarlarının extension domain'ini içerdiğinden emin olun

3. **Network tab'ını kontrol edin:**
   - F12 > Network
   - API isteklerinin başarılı olduğunu kontrol edin

## 📝 Notlar

- Extension sadece **https** üzerinden çalışır
- YouTube Studio'da auto-fill için sayfanın tamamen yüklenmesi gerekir
- Extension, YouTube'un SPA (Single Page Application) yapısına uyumludur
- Her video değiştiğinde otomatik olarak yeniden analiz yapar

## 🔄 Güncelleme

Extension'ı güncellemek için:

1. Yeni dosyaları `extension` klasörüne kopyalayın
2. Chrome'da `chrome://extensions/` sayfasına gidin
3. Extension'ın yanındaki **"Reload"** (Yeniden yükle) butonuna tıklayın

## 🆘 Destek

Sorun yaşıyorsanız:
1. Console loglarını kontrol edin
2. Extension'ın izinlerini kontrol edin
3. API URL'lerinin doğru olduğundan emin olun
4. Dashboard'da API key'in çalıştığını doğrulayın

